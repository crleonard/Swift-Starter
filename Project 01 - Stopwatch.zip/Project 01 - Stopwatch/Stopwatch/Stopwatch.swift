//
//  Stopwatch.swift
//  Stopwatch
//
//  Copyright Chris Leonard © 2019
//

import Foundation

class Stopwatch: NSObject {
  var counter: Double
  var timer: Timer
  
  override init() {
    counter = 0.0
    timer = Timer()
  }
}
